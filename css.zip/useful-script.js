// JavaScript Document
$(document).ready(function() {
	
	//code start
	
	});
	
	function bannervisible() {
	if($('.vsMenuTabs > li:first-child.active').length > 0) {
		$('.banner').addClass("d-flex");
	} else {
		$('.banner').removeClass("d-flex");
	}
}


$(document).ready(function() {
	bannervisible();
	$('#myTab li a').click(function() {
		bannervisible();
		$("#myTab li").removeClass("active");
		$(this).addClass("active");
	});
});


//ADD ON THIS AND REMOVE FROM OTHER
$(document).ready(function() {
	$('.MapPart').on('click', function() {
		$('.MapPart').removeClass('active');
		$(this).addClass('active');
	});
});
//CHECK PREVIOUS CLASS AND MOVE THAT CLASS AFTER SOME CLASS
if($('.mainmenu').prev().hasClass('alert')) $('.mainmenu').after($('.mainmenu').prev())
	// REPLACE TEXT BASED ON PAGE URL
$(document).ready(function() {
	var CurrentUrl = window.location.pathname;
	if(CurrentUrl.indexOf("/en/map") != -1) {
		$('#dnshtitle').html('View All');
	}
});
// ADD AND REMOVE CLASS BASED ON SOME SPECIFIC CLASS OFFSET
$(window).scroll(function() {
	if($(window).scrollTop() >= $(document.getElementsByClassName("section_3")).offset().top) {
		$('.banner').addClass("videoposition");
	} else {
		$('.banner').removeClass("videoposition");
	}
});
//APPEND OWL NAV TO OTHER DIV
$('.intro-feature-wrapper .section-title').append($(".intro-feature-wrapper  div.owl-nav"))
	//TOGGLE CLASS ON CLICK
$(".chooosebtn").click(function() {
	$("#ModalCombineAvaiblityChoose").toggleClass("main");
});
// ADD AND REMOVE CLASS ON CLICK
$(".MenuBarLink").click(function() {
	$("body").addClass("OpenMenuBody");
});
$(".closebtn").click(function() {
	$("body").removeClass("OpenMenuBody");
});
$(".closebtn").click(function() {
	$("body").toggleClass("nav-sm");
});
// REMOVE CLASS AFTER FEW SECOND ON CLICK
$(".dropdown-item").click(function() {
	setTimeout(function() {
		$(".dropdown-menu").removeClass("show");
	}, 1500);
});
// ONCLICK DOCUMENT EXCEPT SPECIFIC CLASS
$(document).on("click", function(e) {
	if($(e.target).closest("#sidebar-menu").length > 0) {
		return false;
	} else {
		$("body").toggleClass("nav-sm");
		$("body").toggleClass("nav-md");
	}
});
//ADD CLASS ON SCROLL
$(window).scroll(function() {
	var scroll = $(window).scrollTop();
	if(scroll >= 20) {
		$(".TopHeadMobile").addClass("bg-black");
	} else {
		$(".TopHeadMobile").removeClass("bg-black");
	}
});
// REMOVE EMPTY TAG
$('.IntroAbt p').each(function() {
	var $this = $(this);
	if($this.html().replace(/\s|&nbsp;/g, '').length == 0) $this.remove();
});
// ON PAGE LOAD TARGET ELEMENT TO SCROLL
$(function() {
	$(document).ready(function() {
		debugger;
		var SuccessElement = $(".bg-success").find('p');
		if(SuccessElement.length > 0) {
			$('html,body').animate({
				scrollTop: $('#ContactForm').offset().top - 100
			}, 1000);
		}
	});
});
// WRAP WITH ANCHORTAG
$('.OmWrapper .map .image_container').each(function() {
	$(this).wrapInner('<a class="info_img2" data-toggle="modal" data-target=".bs-example-modal-lg"/>');
});
// TWO BOOTSTRAP CAROSEL WITH SINGLE BULLET CLICK
$('#SliderText').on('slide.bs.carousel', function(e) {
	$('#SliderImage').carousel(e.to);
});
//SMOOTH SCROLL
$(".StartPoint ,.HomeScrollLink").on('click', function(event) {
	if(this.hash !== "") {
		event.preventDefault();
		var hash = this.hash;
		$('html, body').animate({
			scrollTop: $(hash).offset().top
		}, 800, function() {
			window.location.hash = hash;
		});
	}
	// ON WINDOW RESIZE ADD AND REMOVE CLASS
	$(window).bind("resize", function() {
		if($(this).width() < 800) {
			$('main').addClass('toggled')
		} else {
			$('main').removeClass('toggled')
		}
	}).trigger('resize');
});
// THIS PARENT
$('.nav-tabs a').on('click', function() {
	$(this).parent().parent().parent().parent().addClass('test');
});
// ADD CLASS BASED ON Y AXS
$("body").on('mousemove', '.purchase-list-table', function(event) {
	if(event.pageY > 1836) {
		$(this).find(".tooltip").addClass("BottomTooltip");
	} else {
		$(this).find(".tooltip").removeClass("BottomTooltip");
	};
})
var header = jQuery("#masthead .row.nasa-hide-for-mobile .nasa-wrap-event-search .nasa-relative");
jQuery(window).scroll(function() {
	var scroll = jQuery(window).scrollTop();
	console.log(header);
	if(scroll > 10) {
		console.log(scroll);
		header.removeClass("nasa-invisible");
		jQuery("#masthead .row.nasa-hide-for-mobile .nasa-header-search-wrap .nasa-show-search-form").removeClass("nasa-show");
	}
});
$(window).on("load resize", function() {
	var viewportWidth = $(window).width();
	if(viewportWidth < 768) {
		$(".gallery_n_carousel").addClass("owl-carousel owl-theme");
		$('.gallery_n_carousel').owlCarousel({
			items: 1,
			loop: false,
			autoplay: false,
			dots: false,
			nav: true,
			margin: 20,
			responsiveClass: true,
			responsive: {
				768: {
					items: 1,
				}
			}
		});
		$(".owl-prev").html('<span><i class="fas fa-angle-right"></i></span>');
		$(".owl-next").html('<span><i class="fas fa-angle-right"></i></span>');
	} else {
		$(".gallery_n_carousel").removeClass("owl-carousel owl-theme");
		$('.gallery_n_carousel').owlCarousel('destroy');
	}
});
$(document).ready(function() {
	var topheight = Number($(this).find(".top-wrapper").height());
	$(this).find(".side-left").attr('style', 'height:calc(100vh - ' + (topheight + 30) + 'px )');
});